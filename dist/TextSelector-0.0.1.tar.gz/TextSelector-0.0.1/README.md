# streamlit-textselector

Install: `pip install https://raw.githubusercontent.com/successar/streamlit-textselector/main/dist/TextSelector-0.0.1-py3-none-any.whl`
