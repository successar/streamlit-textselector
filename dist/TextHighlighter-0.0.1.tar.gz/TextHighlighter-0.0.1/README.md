# streamlit-texthighlighter

Install: `pip install https://raw.githubusercontent.com/successar/streamlit-texthighlighter/main/dist/TextHighlighter-0.0.1-py3-none-any.whl`
